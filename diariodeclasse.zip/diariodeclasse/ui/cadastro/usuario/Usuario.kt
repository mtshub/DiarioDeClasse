package com.rafaelcosta.diariodeclasse.ui.cadastro.usuario

import android.net.Uri
import androidx.annotation.DrawableRes
import com.rafaelcosta.diariodeclasse.R

data class Usuario(
    val nome: String,
    val email: String,
    val senha: String,
    val fotoUri: Uri? = null,
    @DrawableRes val fotoPadrao : Int = R.drawable.account_circle
)
