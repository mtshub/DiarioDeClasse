package com.rafaelcosta.diariodeclasse.ui.cadastro

import android.net.Uri
import com.rafaelcosta.diariodeclasse.ui.cadastro.usuario.Usuario

data class CadastroUIState(
    val labelNome: String = "",
    val labelEmail: String = "",
    val labelSenha: String = "",
    val labelConfirmarSenha: String = "",
    val usuarios: List<Usuario> = emptyList(),
    val fotoUri: Uri? = null,
    val senhaNaoCoincide: Boolean = false,
    val cadastroSucesso: Boolean = false
)
